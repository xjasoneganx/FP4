<?php

  $nav_selected = "TRAINS";
  $left_buttons = "YES";
  $left_selected = "GLOBE";

  include("./nav.php");
  global $db;

  ?>

  <h3 style = "color: #01B0F1;">Trains -> Globe: TBD</h3>
  
<?php include("./footer.php"); ?>
