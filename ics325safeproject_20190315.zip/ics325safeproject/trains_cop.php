<?php

  $nav_selected = "TRAINS";
  $left_buttons = "YES";
  $left_selected = "COP";

  include("./nav.php");
  global $db;
?>

<?php include("./footer.php"); ?>
