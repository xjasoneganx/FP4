<?php

  $nav_selected = "PIPLANNING";
  $left_buttons = "YES"; 
  $left_selected = "CEREMONIES";


  include("./nav.php");
  global $db;

  ?>

  <img src="images/work_in_progress.jpg" height = "250" width = "350"/>
  <h3> Ceremonies </h3>
  RELEASE DATE IS TBD


<?php include("./footer.php"); ?>
