<div id="menu-left">
  <a href="trains_list.php">
  	<div <?php if($left_selected == "LIST")
  	{ echo 'class="menu-left-current-page"'; } ?>>
  	<img src="./images/trains_list.png">
  	<br/>List<br/></div>
  </a>

  <a href="trains_lists.php">
  	<div <?php if($left_selected == "LISTS")
  	{ echo 'class="menu-left-current-page"'; } ?>>
  	<img src="./images/trains_lists.png">
  	<br/>Lists<br/></div>
  </a>

  <a href="trains_size.php">
  	<div <?php if($left_selected == "SIZE")
  	{ echo 'class="menu-left-current-page"'; } ?>>
  	<img src="./images/trains_size.png">
  	<br/>Size<br/></div>
  </a>


  <a href="trains_globe.php">
    <div <?php if($left_selected == "GLOBE")
    { echo 'class="menu-left-current-page"'; } ?>>
    <img src="./images/trains_globe.png">
    <br/>Globe<br/></div>
  </a>

  <a href="trains_tree.php">
  	<div <?php if($left_selected == "TREE")
  	{ echo 'class="menu-left-current-page"'; } ?>>
  	<img src="./images/trains_tree.png">
  	<br/>Tree<br/></div>
  </a>

  <a href="trains_hybrid.php">
  	<div <?php if($left_selected == "HYBRID")
  	{ echo 'class="menu-left-current-page"'; } ?>>
  	<img src="./images/trains_hybrid.png">
  	<br/>Hybrid<br/></div>
  </a>

  <a href="trains_cop.php">
    <div <?php if($left_selected == "COP")
    { echo 'class="menu-left-current-page"'; } ?>>
    <img src="./images/training_cop.png">
    <br/>CoP<br/></div>
  </a>

</div>
