<div id="menu-left">
  <a href="training_summary.php">
  	<div <?php if($left_selected == "SUMMARY")
  	{ echo 'class="menu-left-current-page"'; } ?>>
  	<img src="./images/training_summary.png">
  	<br/>Summary<br/></div>
  </a>

  <a href="training_calendar.php">
    <div <?php if($left_selected == "CALENDAR")
    { echo 'class="menu-left-current-page"'; } ?>>
    <img src="./images/training_calendar.png">
    <br/>Calendar<br/></div>
  </a>

  <a href="training_status.php">
  	<div <?php if($left_selected == "STATUS")
  	{ echo 'class="menu-left-current-page"'; } ?>>
  	<img src="./images/training_status.png">
  	<br/>Status<br/></div>
  </a>

  <a href="training_employees.php">
    <div <?php if($left_selected == "EMPLOYEES")
    { echo 'class="menu-left-current-page"'; } ?>>
    <img src="./images/training_employees.png">
    <br/>Employees<br/></div>
  </a>

 <a href="training_costs.php">
    <div <?php if($left_selected == "COSTS")
    { echo 'class="menu-left-current-page"'; } ?>>
    <img src="./images/training_costs.png">
    <br/>Costs<br/></div>
  </a>


 
    
</div>
