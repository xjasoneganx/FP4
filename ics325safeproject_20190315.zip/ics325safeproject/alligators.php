<?php	
//Used for testing
/*  	
	if (isset($_COOKIE["art"])) {
		unset($_COOKIE["art"]);
	}  
*/

// Read the stored value (if any)
$art = $_COOKIE['art'] ?? '';
echo('Cookie ART is: ' . $art .' </br>' );


$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ics325safedb";

$nav_selected = "PIPLANNING";
$left_buttons = "YES"; 
$left_selected = "CEREMONIES";

include("./nav.php");
global $db;

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
?>

<!DOCTYPE HTML>
<html>

<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<meta name="description" content="Agile Release Train">
	<meta name="keywords" content="HTML,CSS,XML,JavaScript">
	<meta name="author" content="Awesome Alligators">
	<link rel="stylesheet" type="text/css" href="css/pitable.css">
	<title>Program Increment (PI) Summary Table</title>
</head>

<body>
<h2>
	Program Increment (PI) Summary Table 
</h2>

<div id="form_content">
<form action="table.php" method="post">


<div id="base_url"></div>

	<table id="input_table">
		<tr>
			<td hidden>Base URL:</td>
			<td>
<?php
	echo('</br>');
	$prefidResult = $conn->query("SELECT * FROM preferences WHERE name = 'BASE_URL' ORDER BY id");
	if ($prefidResult->num_rows > 0) {
		$row =$prefidResult->fetch_assoc();
		$baseUrlDefault = trim($row['value']);
	} else {
		$prefidResult = "0 results";
	}

	$prefDefaultART = $conn->query("SELECT * FROM preferences WHERE name = 'DEFAULT_ART' ORDER BY id");
	if ($prefDefaultART->num_rows > 0) {
		$row =$prefDefaultART->fetch_assoc();
		$artDefault = trim($row['value']);
	} else {
		$prefDefaultART = "0 results";
	}
?>
			<input type="text" id="baseURL" name="baseURL" hidden value="<?php print $baseUrlDefault; ?>"/>
		</td>
		</tr>
		<tr>
			<td>Program Increment ID:</td>
			<td>
<?php
	$piidDefault = $conn->query("select PI_id,MIN(start_date) from cadence where start_date >= curdate() group by PI_id limit 1");
	$piidResult = $conn->query("SELECT DISTINCT PI_id FROM cadence WHERE PI_id != ''");
	if ($piidDefault->num_rows > 0) {
		while($row = $piidDefault->fetch_assoc()) {
			$DefaultPiid = $row["PI_id"];
		}
	} else {
		$DefaultPiid = "0 results";
	}

	echo '<select id="piid" name="piid" value="' . $DefaultPiid . '">' . "\n";
	if ($piidResult->num_rows > 0) {
		while($row = $piidResult->fetch_assoc()) {
			echo '<option value="'. $row["PI_id"] . '"';
				if ($row["PI_id"] == $DefaultPiid) {
					echo ' selected="selected">';
						} else {
					echo '>';}
			echo $row["PI_id"] . '</option>' . "\n";
		}
	} else {
			echo "0 results";
	}
	echo '</select>';
?>
			</td>
		</tr>
		<tr>
			<td>Agile Release Train (ART):</td>
			<td>

<?php
	$query0 = $conn->query("SELECT * FROM trains_and_teams WHERE trim(type)='ART';");
	$query1 = $conn->query("SELECT * FROM trains_and_teams WHERE trim(type)='AT';");

	$ARTresults = array();
	$ATresults = array();

	while($line = mysqli_fetch_assoc($query1)){
			$ATresults[] = $line;
	}

	while($line = mysqli_fetch_assoc($query0)){
			$ARTresults[] = $line;
	}

	while($line = mysqli_fetch_assoc($query1)){
			$ATresults[] = $line;
	}


?>

<script type="text/javascript">
var baseURL2 = JSON.parse('<?php echo json_encode($baseUrlDefault,JSON_HEX_TAG|JSON_HEX_APOS); ?>');  
		document.getElementById("baseURL").innerHTML = baseURL2;	
var table_show = "";
document.write('<select id="artSelector" name="art" onchange="changeATs()">');
var AT = JSON.parse('<?php echo json_encode($ATresults,JSON_HEX_TAG|JSON_HEX_APOS); ?>');
var ART = JSON.parse('<?php echo json_encode($ARTresults,JSON_HEX_TAG|JSON_HEX_APOS); ?>');
var cookie_art    = JSON.parse('<?php echo json_encode($art,JSON_HEX_TAG|JSON_HEX_APOS); ?>');
var db_default_art = JSON.parse('<?php echo json_encode($artDefault,JSON_HEX_TAG|JSON_HEX_APOS); ?>');
console.log('From db ART: ' + db_default_art);

var i=0;
ART.forEach(function(element) {
	
	if(cookie_art != '') {
		if (ART[i].team_id == cookie_art) {
				document.write('<option selected value="' + ART[i].team_id + '">' + ART[i].team_name + '<br />');	
			} else {
					document.write('<option value="' + ART[i].team_id + '">' + ART[i].team_name + '<br />');	
			}	
	} else {
		//document.write('Access value from prefs table code goes here');
		console.log('else_1');
		if (ART[i].team_id==db_default_art) 
		{
			document.write('<option selected value="' + ART[i].team_id + '">' + ART[i].team_name + '<br />');	
		} 
		else 
		{
			document.write('<option value="' + ART[i].team_id + '">' + ART[i].team_name + '<br />');	
		}	
	}	
	i++;
});
</script>

<script>
function changeATs() {
	table_show = "";
	var parent_name = document.getElementById("artSelector");
	var filter = parent_name.options[parent_name.selectedIndex].value;
	console.log('The chosen ART is ' + filter);
	for (i = 0; i < AT.length; i++) {
		if (filter == AT[i].parent_name) {
			console.log(AT[i].team_name + ", ");
			table_show += AT[i].team_name + ", ";
		}
	}
	table_show = table_show.substring(0, table_show.length - 2);

document.getElementById("namesOfTeams").value = table_show;
}
</script>
			</td>
		</tr>
		<tr>
			<td>Names of the Teams:</td>
			<td>
			<input type='text' id='namesOfTeams' name='namesOfTeams' readonly> 
			</td>
		</tr>
		<tr>
			<td>
			</td>
			<td>
				<button id="generate" type="button">Generate (JS)</button>
				<button type="submit">Generate (PHP)</button>
				<button type="reset" value="Reset">Reset</button>
			</td>
		</tr>
	</table>
</form>
</div>

<div id="table_content">
</div>

<script src="scripts/pitable.js"></script>

</body>
</html>

<script>
document.getElementById("table_content").innerHTML = table_show;
</script>

<?php
$conn->close();
?>
<?php include("./footer.php"); ?>