<?php

  $nav_selected = "HELP"; 
  $left_buttons = "YES"; 
  $left_selected = "ABOUT"; 

  include("./nav.php");
  global $db;

  ?>



<?php include("./footer.php"); ?>
