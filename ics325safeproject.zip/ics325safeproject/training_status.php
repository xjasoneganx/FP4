<?php

  $nav_selected = "TRAINING";
  $left_buttons = "YES";
  $left_selected = "STATUS";

  include("./nav.php");
  global $db;
?>


<?php include("./footer.php"); ?>
