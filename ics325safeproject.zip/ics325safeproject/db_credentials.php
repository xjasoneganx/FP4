<?php

DEFINE('DB_SERVER', 'localhost');
DEFINE('DB_NAME', 'ics325safedb');
DEFINE('DB_USER', 'root');
DEFINE('DB_PASS', '');

?>
