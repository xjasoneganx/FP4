<?php

  $nav_selected = "ADMIN"; 
  $left_buttons = "YES"; 
  $left_selected = "IMPORT"; 

  include("./nav.php");
  global $db;

  ?>

<?php include("./footer.php"); ?>
