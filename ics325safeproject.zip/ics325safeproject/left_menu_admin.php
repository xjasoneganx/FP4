<div id="menu-left">
  <a href="admin_import.php"><div <?php if($left_selected == "IMPORT"){ echo 'class="menu-left-current-page"'; } ?>><img src="./images/admin_import.png"><br/>Import<br/></div></a>
  <a href = "admin_export.php"><div <?php if($left_selected == "EXPORT"){ echo 'class="menu-left-current-page"'; } ?>><img src="./images/admin_export.png"><br/>Export<br/></div>
  <a href="admin_backup.php"><div <?php if($left_selected == "BACKUP"){ echo 'class="menu-left-current-page"'; } ?>><img src="./images/admin_backup.png"><br/>Backup<br/></div></a>
  <a href = "admin_users.php"><div <?php if($left_selected == "USERS"){ echo 'class="menu-left-current-page"'; } ?>><img src="./images/admin_users.png"><br/>Users<br/></div>
  <a href = "admin_configure.php"><div <?php if($left_selected == "CONFIGURE"){ echo 'class="menu-left-current-page"'; } ?>><img src="./images/admin_configure.png"><br/>Configure<br/></div>
  <a href = "admin_preferences.php"><div <?php if($left_selected == "PREFERENCES"){ echo 'class="menu-left-current-page"'; } ?>><img src="./images/admin_preferences.png"><br/>Preferences<br/></div>

</div>