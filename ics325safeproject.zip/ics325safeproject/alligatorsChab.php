<?php
$servername = "localhost";
$username = "root";
$password = "";
//$dbname = "ics325safedb";
$dbname = "ics325db";
$nav_selected = "PIPLANNING";
$left_buttons = "YES"; 
$left_selected = "CEREMONIES";


include("./nav.php");
global $db;



// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
?>

<!DOCTYPE HTML>
<html>

<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<meta name="description" content="Agile Release Train">
	<meta name="keywords" content="HTML,CSS,XML,JavaScript">
	<meta name="author" content="Awesome Alligators">
	<link rel="stylesheet" type="text/css" href="css/pitable.css">
	<title>Program Increment (PI) Summary Table</title>
</head>

<body>
<h2>
	Program Increment (PI) Summary Table 
</h2>

<div id="form_content">
<form action="table.php" method="post">
	<table id="input_table">
		<tr>
			<td>Base URL:</td>
			<td>
			<input type="text" id="baseURL" name="baseURL" value="https://metro">
			</td>
		</tr>
		<tr>
			<td>Program Increment ID:</td>
			<td>
<?php
$piidDefault = $conn->query("select PI_id,MIN(start_date) from cadence where start_date >= curdate() group by PI_id limit 1");
$piidResult = $conn->query("SELECT DISTINCT PI_id FROM cadence WHERE PI_id != ''");

if ($piidDefault->num_rows > 0) {
  while($row = $piidDefault->fetch_assoc()) {
    $DefaultPiid = $row["PI_id"];
  }
} else {
  $DefaultPiid = "0 results";
}

echo '<select id="piid" name="piid" value="' . $DefaultPiid . '">' . "\n";
if ($piidResult->num_rows > 0) {
  while($row = $piidResult->fetch_assoc()) {
    echo '<option value="'. $row["PI_id"] . '"';
      if ($row["PI_id"] == $DefaultPiid) {
        echo ' selected="selected">';
        	} else {
        echo '>';}
    echo $row["PI_id"] . '</option>' . "\n";
  }
} else {
    echo "0 results";
}
echo '</select>';
?>

			</td>
		</tr>
		<tr>
			<td>Agile Release Train (ART):</td>
			<td>

<?php
$query0 = $conn->query("SELECT * FROM trains_and_teams WHERE type='ART';");
$query1 = $conn->query("SELECT * FROM trains_and_teams WHERE type='AT';");

$ARTresults = array();
$ATresults = array();

while($line = mysqli_fetch_assoc($query1)){
    $ATresults[] = $line;
}

while($line = mysqli_fetch_assoc($query0)){
    $ARTresults[] = $line;
}

while($line = mysqli_fetch_assoc($query1)){
    $ATresults[] = $line;
}
?>

<script type="text/javascript">
var table_show = "";
document.write('<select id="artSelector" name="art" onchange="changeATs(this.form)">');
var AT = JSON.parse('<?php echo json_encode($ATresults,JSON_HEX_TAG|JSON_HEX_APOS); ?>');
var ART = JSON.parse('<?php echo json_encode($ARTresults,JSON_HEX_TAG|JSON_HEX_APOS); ?>');
var i=0;
ART.forEach(function(element) {
	document.write(
		'<option value="' + ART[i].team_id + '">' + ART[i].team_name + '<br />'
	);
	i++;
});





</script>
</select>

</select>
<script>
function changeATs(form) {
/* 	table_show = "";
	var parent_name = document.getElementById("artSelector");
	var filter = parent_name.options[parent_name.selectedIndex].value;
	console.log('The chosen ART is ' + filter);
	for (i = 0; i < AT.length; i++) {
		if (filter == AT[i].parent_name) {
			console.log(AT[i].team_name + ", ");
			table_show += AT[i].team_name + ", ";
		}
	}
	table_show = table_show.substring(0, table_show.length - 2);

document.getElementById("namesOfTeams").value = table_show; */

	//var parent_name = document.getElementById("artSelector").value;
	//console.log('The chosen ART is ' + parent_name)	;	

	//var ART_value_obj = document.getElementById("artSelector").value;
	//console.log('The chosen ART_value_obj:' + ART_value_obj)	;	
	var ART_index_num = form.art.selectedIndex;
	console.log('The chosen ART_index_num: ' + ART_index_num)	;	
	var ART_text_obj = form.art.options[ART_index_num].text;
	console.log('The chosen ART_text_obj:' + ART_text_obj)	;	
	
	//var AT_value = document.getElementById("namesOfTeams").options[ART_index_num].value;
	//console.log('The chosen AT_value: ' + AT_value)	;	

	var AT_text_obj = form.art.options[ART_index_num].value;
	console.log('The chosen AT_text_obj: ' + AT_text_obj)	;	

	var AT_value = document.getElementById("namesOfTeams");
	AT_value.innerHTML="";
	var newOption = document.createElement("option");
	newOption.value = AT_text_obj;
	newOption.innerHTML = AT_text_obj;
	AT_value.options.add(newOption);

}
</script>



			</td>
		</tr>
		<tr>
			<td>Names of the Teams:</td>
			<td>

			<!-- <input type='text' id='namesOfTeams' name='namesOfTeams'> -->
			<script type="text/javascript">
				document.write('<select id="namesOfTeams" name="namesOfTeams">');
				var AT = JSON.parse('<?php echo json_encode($ARTresults,JSON_HEX_TAG|JSON_HEX_APOS); ?>');
				var i=0;
				AT.forEach(function(element) {
					document.write(
						//'<option value="' + AT[i].team_id + '">' + AT[i].team_name + '</option><br />'
						'<option value="' + AT[i].team_name + '">' + AT[i].team_id + '</option><br />'
					);
					i++;
				});

				</script>
				</select>



			</td>
		</tr>
		<tr>
			<td>
			</td>
			<td>
				<button id="generate" type="button">Generate (JS)</button>
				<button type="submit">Generate (PHP)</button>
				<button type="reset" value="Reset">Reset</button>

			</td>
		</tr>
	</table>
</form>
</div>

<div id="table_content">
</div>

<script src="scripts/pitable.js"></script>

</body>
</html>

<script>
document.getElementById("content").innerHTML = table_show;
</script>

<?php
$conn->close();
?>
<?php include("./footer.php"); ?>