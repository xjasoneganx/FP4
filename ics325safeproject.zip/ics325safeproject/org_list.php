<?php
  $nav_selected = "ORG";
  $left_buttons = "YES";
  $left_selected = "LIST";

  include("./nav.php");
  global $db;
?>

      <h3 style = "color: #01B0F1;">Org -> List:</h3>

  <?php include("./footer.php"); ?>
