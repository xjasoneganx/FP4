<?php

  $nav_selected = "TRAINS";
  $left_buttons = "YES";
  $left_selected = "HYBRID";

  include("./nav.php");
  global $db;

  ?>

  <h3 style = "color: #01B0F1;">Trains -> Hybrid:</h3>

  <h3> HYBRID: TBD </h3>
  
<?php include("./footer.php"); ?>
