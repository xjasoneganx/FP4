<?php
$nav_selected = "";
$left_buttons = "NO";

  include("./nav.php");
  global $db;

  ?>

<html>

<head>
	<title> Agile Release Train: View </title>
</head>

<body>

</body>
</html>


<?php include("./footer.php"); ?>
