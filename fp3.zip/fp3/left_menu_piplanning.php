<div id="menu-left">
  <a href="piplanning_active_pi.php">
  	<div <?php if($left_selected == "ACTIVE_PI")
  	{ echo 'class="menu-left-current-page"'; } ?>>
  	<img src="./images/piplanning_active_pi.png">
  	<br/>Active PI<br/></div>
  </a>

  <a href = "piplanning_cadence.php">
  	<div <?php if($left_selected == "CADENCE")
  	{ echo 'class="menu-left-current-page"'; } ?>>
  	<img src="./images/piplanning_cadence.png">
  	<br/>Cadence<br/></div>
  </a>

  <a href = "alligators.php">
  	<div <?php if($left_selected == "STATUS")
  	{ echo 'class="menu-left-current-page"'; } ?>>
  	<img src="./images/status.png">
  	<br/>Status<br/></div>
  </a>

  <a href = "piplanning_ceremonies.php">
    <div <?php if($left_selected == "CEREMONIES")
    { echo 'class="menu-left-current-page"'; } ?>>
    <img src="./images/piplanning_ceremonies.png">
    <br/>Ceremonies<br/></div>
  </a>

  <a href="piplanning_capacity.php">
  	<div <?php if($left_selected == "CAPACITY")
  	{ echo 'class="menu-left-current-page"'; } ?>>
  	<img src="./images/piplanning_capacity.png">
  	<br/>Capacity<br/></div>
  </a>

  <a href = "piplanning_summary.php">
  	<div <?php if($left_selected == "SUMMARY")
  	{ echo 'class="menu-left-current-page"'; } ?>>
  	<img src="./images/piplanning_summary.png">
  	<br/>Summary<br/></div>
  </a>

  <a href = "piplanning_trend.php">
  	<div <?php if($left_selected == "TREND")
  	{ echo 'class="menu-left-current-page"'; } ?>>
  	<img src="./images/piplanning_trend.png">
  	<br/>Trend<br/></div>
  </a>

</div>
