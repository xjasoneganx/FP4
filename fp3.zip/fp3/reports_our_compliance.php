<?php

  $nav_selected = "REPORTS"; 
  $left_buttons = "YES"; 
  $left_selected = "OUR_COMPLIANCE"; 

  include("./nav.php");
  global $db;

  ?>

<?php include("./footer.php"); ?>
