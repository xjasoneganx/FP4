<?php

  $nav_selected = "PIPLANNING";
  $left_buttons = "YES"; 
  $left_selected = "CAPACITY";


  include("./nav.php");
  global $db;

  ?>

  <img src="images/work_in_progress.jpg" height = "250" width = "350"/>
  <h3> CAPACITY CALCULATOR NOT READY YET </h3>
  Awesome Alligators are currently developing the capacity calculator.
  Please check back later.


<?php include("./footer.php"); ?>
