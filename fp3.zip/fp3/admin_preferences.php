<?php

  $nav_selected = "ADMIN";
  $left_buttons = "YES"; 
  $left_selected = "PREFERENCES";

  include("./nav.php");
  
    require_once('./initialize.php');
?>

  <?php include("./footer.php"); ?>
