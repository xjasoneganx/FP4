<?php 

include("./nav.php");
global $db;

?>

