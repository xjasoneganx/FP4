<?php

  $costPerEnrollment = 100;

  $nav_selected = "TRAINING";
  $left_buttons = "YES";
  $left_selected = "COSTS";

  include("./nav.php");
  global $db;
?>

<?php include("./footer.php"); ?>
