<?php
  $nav_selected = "TRAINING";
  $left_buttons = "NO";

  include("./nav.php");
  global $db;
?>

  <?php include("./footer.php"); ?>
