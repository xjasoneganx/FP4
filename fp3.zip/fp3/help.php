<?php

  $nav_selected = "HELP"; 
  $left_buttons = "YES"; 
  $left_selected = "FAQS"; 

  include("./nav.php");
  global $db;

  ?>

  <img src="images/work_in_progress.jpg" height = "200" width = "200"/>
  <h2> Frequently Asked Questions (FAQs) </h2>
  <br>
  <h3> Top 10 questions we receive are addressed here </h3>
  

<?php include("./footer.php"); ?>
