<div id="menu-left">   
<div <?php
	if ($left_selected == "LIST") {
	    echo 'class="menu-left-current-page"';
	}
	?>>
	<img src="./images/image11.png"><br/>List<br/>
</div>   

<div <?php
	if ($left_selected == "LISTS") {
	    echo 'class="menu-left-current-page"';
	}
	?>>
	<img src="./images/image19.png"><br/>Lists<br/>
</div>   

<div
	<?php
	if ($left_selected == "GRID") {
	    echo 'class="menu-left-current-page"';
	}
	?>>
	<img src="./images/image12.png"><br/>Grid<br/>
</div>

<div <?php
	if ($left_selected == "TREE") {
	    echo 'class="menu-left-current-page"';
	}
	?>>
	<img src="./images/image14.png"><br/>Tree<br/>
</div>   

<div <?php
		if ($left_selected == "HYBRID") {
		    echo 'class="menu-left-current-page"';
		}
	?>>
	<img src="./images/image13.png"><br/>Hybrid<br/>
</div> 

</div>