<?php

  $nav_selected = "ADMIN"; 
  $left_buttons = "YES"; 
  $left_selected = "EXPORT"; 

  include("./nav.php");
  global $db;

  ?>


  <img src="images/work_in_progress.jpg" height = "100" width = "100"/>
  <h3> EXPORT</h3>
  
  TBD

<?php include("./footer.php"); ?>
