<?php

  $nav_selected = "REPORTS";
  $left_buttons = "YES";
  $left_selected = "ROLE_GAPS";

  include("./nav.php");
  global $db;

  ?>


<?php include("./footer.php"); ?>
