<div id="menu-left">
  <a href="help_faqs.php">
  	<div <?php if($left_selected == "FAQS")
    	{ echo 'class="menu-left-current-page"'; } ?>>
    	<img src="./images/help_faqs.png">
  	<br/>FAQs<br/></div>
  </a>

  <a href="help_lpm.php">
    <div <?php if($left_selected == "LPM")
      { echo 'class="menu-left-current-page"'; } ?>>
      <img src="./images/help_lpm.png">
    <br/>LPM<br/></div>
  </a>

  <a href="help_lace.php">
    <div <?php if($left_selected == "LACE")
      { echo 'class="menu-left-current-page"'; } ?>>
      <img src="./images/help_lace.png">
    <br/>LACE<br/></div>
  </a>

  <a href="help_cookies.php">
    <div <?php if($left_selected == "COOKIES")
      { echo 'class="menu-left-current-page"'; } ?>>
      <img src="./images/help_cookies.png">
    <br/>Cookies<br/></div>
  </a>

  <a href="help_bugs.php">
    <div <?php if($left_selected == "BUGS")
        { echo 'class="menu-left-current-page"'; } ?>>
        <img src="./images/help_bugs.png">
      <br/>Bugs<br/></div>
  </a>

 <a href="help_about.php">
    <div <?php if($left_selected == "ABOUT")
      { echo 'class="menu-left-current-page"'; } ?>>
      <img src="./images/help_about.png">
    <br/>About<br/></div>
  </a>

</div>
