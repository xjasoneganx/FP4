<div id="menu-left">
  <a href="reports_summary.php">
  	<div <?php if($left_selected == "SUMMARY")
  	{ echo 'class="menu-left-current-page"'; } ?>>
  	<img src="./images/reports_summary.png">
  	<br/>Summary<br/></div>
  </a>

  <a href="reports_role_gaps.php">
    <div <?php if($left_selected == "ROLE_GAPS")
    { echo 'class="menu-left-current-page"'; } ?>>
    <img src="./images/reports_gaps.png">
    <br/>Role Gaps<br/></div>
  </a>

  <a href="reports_co_location.php">
  	<div <?php if($left_selected == "CO_LOCATION")
  	{ echo 'class="menu-left-current-page"'; } ?>>
  	<img src="./images/reports_co_location.png">
  	<br/>Co-Location<br/></div>
  </a>

  <a href="reports_one_to_many.php">
    <div <?php if($left_selected == "ONE_TO_MANY")
    { echo 'class="menu-left-current-page"'; } ?>>
    <img src="./images/reports_one_to_many.png">
    <br/>One To Many<br/></div>
  </a>

 <a href="reports_one_to_none.php">
    <div <?php if($left_selected == "ONE_TO_NONE")
    { echo 'class="menu-left-current-page"'; } ?>>
    <img src="./images/reports_one_to_none.png">
    <br/>One To None<br/></div>
  </a>

  <a href="reports_mailing_lists.php">
    <div <?php if($left_selected == "MAILING_LIST")
    { echo 'class="menu-left-current-page"'; } ?>>
    <img src="./images/reports_mailing_list.png">
    <br/>Mailing Lists<br/></div>
  </a>

 <a href="reports_our_compliance.php">
    <div <?php if($left_selected == "OUR_COMPLIANCE")
    { echo 'class="menu-left-current-page"'; } ?>>
    <img src="./images/reports_our_compliance.png">
    <br/>Our Compliance<br/></div>
  </a>

<a href="reports_safe_compliance.php">
    <div <?php if($left_selected == "SAFE_COMPLIANCE")
    { echo 'class="menu-left-current-page"'; } ?>>
    <img src="./images/reports_safe_compliance.png">
    <br/>SAFe Compliance<br/></div>
  </a>

  <a href="reports_safe_org_comparison.php">
    <div <?php if($left_selected == "SAFE_COMPARISON")
    { echo 'class="menu-left-current-page"'; } ?>>
    <img src="./images/reports_comparison.png">
    <br/>Comparison Report<br/></div>
  </a>
     
</div>
